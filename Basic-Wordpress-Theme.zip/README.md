# Basic-Wordpress-Theme

![Cover Bro](https://github.com/RaddyTheBrand/Basic-Wordpress-Theme/blob/master/screenshot.png)
THis is the basic wordpress theme that I've been developing as part of some of my YouTube tutoririals.

[Part 1 Design](https://www.youtube.com/watch?v=wEEOiKlzUi8)
[Part 2 HTML](https://www.youtube.com/watch?v=eEZsF6OPKms)
[Part 3 CSS](https://www.youtube.com/watch?v=LEAiAn4OGZ4)
[Part 4 WP](https://www.youtube.com/watch?v=LSllvqX4KtU)


CopyRight Photos
[Unsplash](https://google.com)